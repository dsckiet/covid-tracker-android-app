<p align="left">
	<img width="240" src="https://raw.githubusercontent.com/dsckiet/resources/master/dsckiet-logo.png" />
	<h2 align="left"> < ADD PROJECT TITLE > </h2>
	<h4 align="left"> < ADD PROJECT DESCRIPTION > <h4>
</p>

---
[![DOCS](https://img.shields.io/badge/Documentation-see%20docs-green?style=for-the-badge&logo=appveyor)](INSERT_LINK_FOR_DOCS_HERE) 
  [![UI ](https://img.shields.io/badge/User%20Interface-Link%20to%20UI-orange?style=for-the-badge&logo=appveyor)](INSERT_UI_LINK_HERE)


## Functionalities
- [ ]  < ADD FUNCTIONALITY >
- [ ]  < ADD FUNCTIONALITY >

<br>


## Instructions to run

* Pre-requisites:
	-  < add pre-requisite >
	-  < add pre-requisite >

* Directions to setup/install
```bash
< insert code >
```

* Directions to execute

```bash
< insert code >
```

<br>

## Contributors

* [ < ADD YOUR NAME > ](ADD_PROFILE_URL_HERE)



<br>
<br>

<p align="center">
	Made during 🌙 by DSC KIET
</p>
